package mx.unam.die.poo.g7.practica_7.src;

/**
 * Clase que representa un trapezoide, hereda de Cuadrilatero y permite calcular su área
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Trapezoide extends Cuadrilatero {

    /**
     * Área del trapezoide
     */
    private double area;

    /**
     * Constructor que inicializa los cuatro vértices del trapezoide
     * 
     * @param punto1 Primer vértice
     * @param punto2 Segundo vértice
     * @param punto3 Tercer vértice
     * @param punto4 Cuarto vértice
     */
    public Trapezoide(Punto punto1, Punto punto2, Punto punto3, Punto punto4) {
        super(punto1, punto2, punto3, punto4);
    }

    /**
     * Calcula el área del trapezoide mediante la fórmula A = ((B + b) * h) / 2
     * 
     * @return retorna el área calculada del trapezoide
     */
    public double calcularArea() {
        double baseMayor = Math.abs(getVertice2().getX() - getVertice1().getX());
        double baseMenor = Math.abs(getVertice3().getX() - getVertice4().getX());
        double altura = Math.abs(getVertice3().getY() - getVertice1().getY());
        this.area = ((baseMayor + baseMenor) * altura) / 2.0;
        return this.area;
    }
}
