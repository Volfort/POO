package mx.unam.die.poo.g7.practica_7.src;

/**
 * Clase que representa un paralelogramo, hereda de Trapezoide y calcula su área como base por altura
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Paralelogramo extends Trapezoide {

    /**
     * Constructor que inicializa los cuatro vértices del paralelogramo
     * 
     * @param punto1 Primer vértice
     * @param punto2 Segundo vértice
     * @param punto3 Tercer vértice
     * @param punto4 Cuarto vértice
     */
    public Paralelogramo(Punto punto1, Punto punto2, Punto punto3, Punto punto4) {
        super(punto1, punto2, punto3, punto4);
    }

    /**
     * Calcula el área del paralelogramo mediante la fórmula A = b * h
     * 
     * @return retorna el área calculada del paralelogramo
     */
    @Override
    public double calcularArea() {
        double base = Math.abs(getVertice2().getX() - getVertice1().getX());
        double altura = Math.abs(getVertice3().getY() - getVertice1().getY());
        return base * altura;
    }
}
