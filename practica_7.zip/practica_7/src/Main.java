package mx.unam.die.poo.g7.practica_7.src;

/**
 * Clase principal que instancia objetos de la jerarquía de cuadriláteros
 * y muestra en consola los vértices y el área de cada figura geométrica
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Main {

    /**
     * Método principal que ejecuta las pruebas de la jerarquía de herencia
     * 
     * @param args Argumentos pasados por la línea de comandos
     */
    public static void main(String[] args) {
        Cuadrilatero cuadrilatero = new Cuadrilatero(
            new Punto(1, 1),
            new Punto(5, 2),
            new Punto(4, 6),
            new Punto(0, 4)
        );
        System.out.println("=== Cuadrilatero ===");
        mostrarVertices(cuadrilatero);

        Trapezoide trapezoide = new Trapezoide(
            new Punto(0, 0),
            new Punto(8, 0),
            new Punto(6, 4),
            new Punto(2, 4)
        );
        System.out.println("\n=== Trapezoide ===");
        mostrarVertices(trapezoide);
        System.out.println("Area del Trapezoide: " + trapezoide.calcularArea());

        Paralelogramo paralelogramo = new Paralelogramo(
            new Punto(0, 0),
            new Punto(6, 0),
            new Punto(8, 4),
            new Punto(2, 4)
        );
        System.out.println("\n=== Paralelogramo ===");
        mostrarVertices(paralelogramo);
        System.out.println("Area del Paralelogramo: " + paralelogramo.calcularArea());

        Rectangulo rectangulo = new Rectangulo(
            new Punto(0, 0),
            new Punto(6, 0),
            new Punto(6, 4),
            new Punto(0, 4)
        );
        System.out.println("\n=== Rectangulo ===");
        mostrarVertices(rectangulo);
        System.out.println("Area del Rectangulo: " + rectangulo.calcularArea());

        Cuadrado cuadrado = new Cuadrado(
            new Punto(0, 0),
            new Punto(5, 0),
            new Punto(5, 5),
            new Punto(0, 5)
        );
        System.out.println("\n=== Cuadrado ===");
        mostrarVertices(cuadrado);
        System.out.println("Area del Cuadrado: " + cuadrado.calcularArea());
    }

    /**
     * Muestra en consola las coordenadas de los cuatro vértices de un cuadrilátero
     * 
     * @param c Objeto de tipo Cuadrilatero del cual se mostrarán los vértices
     */
    public static void mostrarVertices(Cuadrilatero c) {
        System.out.println("P1(" + c.getVertice1().getX() + ", " + c.getVertice1().getY() + ")");
        System.out.println("P2(" + c.getVertice2().getX() + ", " + c.getVertice2().getY() + ")");
        System.out.println("P3(" + c.getVertice3().getX() + ", " + c.getVertice3().getY() + ")");
        System.out.println("P4(" + c.getVertice4().getX() + ", " + c.getVertice4().getY() + ")");
    }
}
