package mx.unam.die.poo.g7.practica_7.src;

/**
 * Clase que representa un cuadrado, hereda de Rectangulo y calcula su área elevando su lado al cuadrado
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Cuadrado extends Rectangulo {

    /**
     * Constructor que inicializa los cuatro vértices del cuadrado
     * 
     * @param punto1 Primer vértice
     * @param punto2 Segundo vértice
     * @param punto3 Tercer vértice
     * @param punto4 Cuarto vértice
     */
    public Cuadrado(Punto punto1, Punto punto2, Punto punto3, Punto punto4) {
        super(punto1, punto2, punto3, punto4);
    }

    /**
     * Calcula el área del cuadrado mediante la fórmula A = b^2
     * 
     * @return retorna el área calculada del cuadrado
     */
    @Override
    public double calcularArea() {
        double lado = Math.abs(getVertice2().getX() - getVertice1().getX());
        return lado * lado;
    }
}
