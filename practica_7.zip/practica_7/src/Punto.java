package mx.unam.die.poo.g7.practica_7.src;

/**
 * Clase que representa un punto en el plano cartesiano con coordenadas (x, y)
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Punto {

    /**
     * Coordenada en el eje X
     */
    private double x;

    /**
     * Coordenada en el eje Y
     */
    private double y;

    /**
     * Constructor que inicializa las coordenadas del punto
     * 
     * @param x Coordenada en el eje X
     * @param y Coordenada en el eje Y
     */
    public Punto(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Obtiene la coordenada X del punto
     * 
     * @return retorna el valor de la coordenada x
     */
    public double getX() {
        return x;
    }

    /**
     * Obtiene la coordenada Y del punto
     * 
     * @return retorna el valor de la coordenada y
     */
    public double getY() {
        return y;
    }
}
