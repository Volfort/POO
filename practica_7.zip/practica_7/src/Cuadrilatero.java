package mx.unam.die.poo.g7.practica_7.src;

/**
 * Superclase que representa un cuadrilátero general mediante sus cuatro vértices
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Cuadrilatero {

    /**
     * Primer vértice del cuadrilátero
     */
    private Punto vertice1;

    /**
     * Segundo vértice del cuadrilátero
     */
    private Punto vertice2;

    /**
     * Tercer vértice del cuadrilátero
     */
    private Punto vertice3;

    /**
     * Cuarto vértice del cuadrilátero
     */
    private Punto vertice4;

    /**
     * Constructor que inicializa los cuatro vértices del cuadrilátero
     * 
     * @param v1 Primer vértice
     * @param v2 Segundo vértice
     * @param v3 Tercer vértice
     * @param v4 Cuarto vértice
     */
    public Cuadrilatero(Punto v1, Punto v2, Punto v3, Punto v4) {
        this.vertice1 = v1;
        this.vertice2 = v2;
        this.vertice3 = v3;
        this.vertice4 = v4;
    }

    /**
     * Obtiene el primer vértice del cuadrilátero
     * 
     * @return retorna el objeto Punto del vértice 1
     */
    public Punto getVertice1() {
        return vertice1;
    }

    /**
     * Obtiene el segundo vértice del cuadrilátero
     * 
     * @return retorna el objeto Punto del vértice 2
     */
    public Punto getVertice2() {
        return vertice2;
    }

    /**
     * Obtiene el tercer vértice del cuadrilátero
     * 
     * @return retorna el objeto Punto del vértice 3
     */
    public Punto getVertice3() {
        return vertice3;
    }

    /**
     * Obtiene el cuarto vértice del cuadrilátero
     * 
     * @return retorna el objeto Punto del vértice 4
     */
    public Punto getVertice4() {
        return vertice4;
    }
}
