package poo.g7.e0.py2.src.pacientes;

/**
 * Representa a un paciente de medicina general con su motivo de consulta
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class PacienteGeneral extends Paciente {
    /**
     * Motivo de la consulta del paciente
     */
    private String motivoConsulta;

    /**
     * Crea un paciente general con sus datos y motivo de consulta
     * 
     * @param nombre Nombre del paciente
     * @param apellidos Apellidos del paciente
     * @param motivoConsulta Motivo por el que va a consulta
     */
    public PacienteGeneral(String nombre, String apellidos, String motivoConsulta) {
        super(nombre, apellidos);
        this.motivoConsulta = motivoConsulta;
    }

    /**
     * Obtiene el motivo de consulta
     * 
     * @return Motivo de consulta
     */
    public String getMotivoConsulta() {
        return this.motivoConsulta;
    }

    /**
     * Muestra la ficha del paciente con su motivo de consulta
     */
    public void mostrarFichaGeneral() {
        System.out.println("Ficha del paciente: " + getNombre() + " " + getApellidos() + " motivo: " + this.motivoConsulta);
    }

    /**
     * Solicita consulta para medicina general
     */
    @Override
    public void solicitarConsulta() {
        setEstado('E');
        System.out.println("El paciente general " + getNombre() + " solicita atencion en medicina general por: " + this.motivoConsulta);
    }

    /**
     * Regresa Medicina General como tipo de atención
     * 
     * @return Tipo de atención del paciente
     */
    @Override
    public String getTipoAtencion() {
        return "Medicina General";
    }
}
