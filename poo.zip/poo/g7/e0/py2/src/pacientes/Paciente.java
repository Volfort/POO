package poo.g7.e0.py2.src.pacientes;

/**
 * Clase base para representar a un paciente del hospital, sus datos
 * y su estado dentro del proceso de atención médica
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public abstract class Paciente {
    /**
     * Nombre del paciente
     */
    private String nombre;

    /**
     * Apellidos del paciente
     */
    private String apellidos;

    /**
     * Estado del paciente: E (Espera), R (Registrado), C (Consulta), T (Tratamiento), A (Curado)
     */
    private char estado;

    /**
     * Crea un paciente con su nombre y apellidos
     * 
     * @param nombre Nombre del paciente
     * @param apellidos Apellidos del paciente
     */
    public Paciente(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.estado = 'E';
    }

    /**
     * Obtiene el nombre del paciente
     * 
     * @return Nombre del paciente
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene los apellidos del paciente
     * 
     * @return Apellidos del paciente
     */
    public String getApellidos() {
        return this.apellidos;
    }

    /**
     * Obtiene el estado actual del paciente
     * 
     * @return Estado del paciente
     */
    public char getEstado() {
        return this.estado;
    }

    /**
     * Cambia el estado del paciente
     * 
     * @param nuevoEstado Nuevo estado del paciente
     */
    public void setEstado(char nuevoEstado) {
        this.estado = nuevoEstado;
    }

    /**
     * Registra al paciente en el sistema y cambia su estado a registrado
     */
    public void registroEnSistema() {
        this.estado = 'R';
        System.out.println("Paciente " + this.nombre + " " + this.apellidos + " registrado en el sistema.");
    }

    /**
     * Muestra en consola el estado actual del paciente
     */
    public void verTratamiento() {
        String descripcion = "";
        if (this.estado == 'E') {
            descripcion = "En espera";
        } else if (this.estado == 'R') {
            descripcion = "Registrado";
        } else if (this.estado == 'C') {
            descripcion = "En consulta";
        } else if (this.estado == 'T') {
            descripcion = "En tratamiento";
        } else if (this.estado == 'A') {
            descripcion = "Curado";
        }
        System.out.println("Paciente: " + this.nombre + " " + this.apellidos + " estado: " + descripcion);
    }

    /**
     * Solicita consulta según el tipo de paciente
     */
    public abstract void solicitarConsulta();

    /**
     * Obtiene el tipo de atención o especialidad que requiere el paciente
     * 
     * @return Tipo de atención o especialidad
     */
    public abstract String getTipoAtencion();
}
