package poo.g7.e0.py2.src.pacientes;

/**
 * Representa a un paciente de especialidad con el área médica que necesita
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class PacienteEspecialidad extends Paciente {
    /**
     * Especialidad que requiere el paciente
     */
    private String especialidad;

    /**
     * Crea un paciente de especialidad con sus datos
     * 
     * @param nombre Nombre del paciente
     * @param apellidos Apellidos del paciente
     * @param especialidad Especialidad que necesita el paciente
     */
    public PacienteEspecialidad(String nombre, String apellidos, String especialidad) {
        super(nombre, apellidos);
        this.especialidad = especialidad;
    }

    /**
     * Obtiene la especialidad del paciente
     * 
     * @return Especialidad del paciente
     */
    public String getEspecialidad() {
        return this.especialidad;
    }

    /**
     * Muestra la ficha del paciente con su especialidad
     */
    public void mostrarFichaEspecialidad() {
        System.out.println("Ficha del paciente: " + getNombre() + " " + getApellidos() + " especialidad: " + this.especialidad);
    }

    /**
     * Solicita consulta para la especialidad indicada
     */
    @Override
    public void solicitarConsulta() {
        setEstado('E');
        System.out.println("El paciente de especialidad " + getNombre() + " solicita atencion en: " + this.especialidad);
    }

    /**
     * Regresa la especialidad del paciente como tipo de atención
     * 
     * @return Especialidad del paciente
     */
    @Override
    public String getTipoAtencion() {
        return this.especialidad;
    }
}
