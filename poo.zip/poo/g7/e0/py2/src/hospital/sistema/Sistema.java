package poo.g7.e0.py2.src.hospital.sistema;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import poo.g7.e0.py2.src.pacientes.Paciente;
import poo.g7.e0.py2.src.pacientes.PacienteGeneral;
import poo.g7.e0.py2.src.pacientes.PacienteEspecialidad;
import poo.g7.e0.py2.src.personal.Medico;
import poo.g7.e0.py2.src.personal.MedicoGeneral;
import poo.g7.e0.py2.src.personal.MedicoEspecialista;
import poo.g7.e0.py2.src.personal.Enfermero;
import poo.g7.e0.py2.src.personal.EnfermeroGeneral;
import poo.g7.e0.py2.src.personal.EnfermeroEspecialista;
import poo.g7.e0.py2.src.personal.JefeEnfermeria;

/**
 * Clase principal que gestiona el sistema del hospital, el registro
 * y almacenamiento de médicos, enfermeros y pacientes, la asignación, flujo,
 * tratamiento y alta médica de los pacientes
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Sistema {
    /**
     * Nombre del hospital
     */
    private String nombreHospital;

    /**
     * Número de médicos registrados
     */
    private int noMedicos;

    /**
     * Número de enfermeros registrados
     */
    private int noEnfermeros;

    /**
     * Número de pacientes en espera
     */
    private int noPacientes;

    /**
     * Arreglo de médicos del hospital
     */
    private ArrayList<Medico> listaMedicos;

    /**
     * Arreglo de enfermeros del hospital
     */
    private ArrayList<Enfermero> listaEnfermeros;

    /**
     * Arreglo de pacientes en espera
     */
    private ArrayList<Paciente> listaPacientes;

    /**
     * Arreglo de pacientes curados
     */
    private ArrayList<Paciente> listaCurados;

    /**
     * Crea el sistema del hospital e inicializa las listas y contadores
     */
    public Sistema() {
        this.nombreHospital = "Hospital La Raza";
        this.noMedicos = 0;
        this.noEnfermeros = 0;
        this.noPacientes = 0;
        this.listaMedicos = new ArrayList<Medico>();
        this.listaEnfermeros = new ArrayList<Enfermero>();
        this.listaPacientes = new ArrayList<Paciente>();
        this.listaCurados = new ArrayList<Paciente>();
    }

    /**
     * Obtiene el nombre del hospital
     * 
     * @return Nombre del hospital
     */
    public String getNombreHospital() {
        return this.nombreHospital;
    }

    /**
     * Obtiene el número de médicos registrados
     * 
     * @return Número de médicos
     */
    public int getNoMedicos() {
        return this.noMedicos;
    }

    /**
     * Obtiene el número de enfermeros registrados
     * 
     * @return Número de enfermeros
     */
    public int getNoEnfermeros() {
        return this.noEnfermeros;
    }

    /**
     * Obtiene el número de pacientes en espera en el hospital
     * 
     * @return Número de pacientes
     */
    public int getNoPacientes() {
        return this.noPacientes;
    }

    /**
     * Obtiene la lista de médicos del hospital
     * 
     * @return Lista de médicos
     */
    public ArrayList<Medico> getListaMedicos() {
        return this.listaMedicos;
    }

    /**
     * Obtiene la lista de enfermeros del hospital
     * 
     * @return Lista de enfermeros
     */
    public ArrayList<Enfermero> getListaEnfermeros() {
        return this.listaEnfermeros;
    }

    /**
     * Obtiene la lista de pacientes en espera del hospital
     * 
     * @return Lista de pacientes
     */
    public ArrayList<Paciente> getListaPacientes() {
        return this.listaPacientes;
    }

    /**
     * Obtiene la lista de pacientes curados
     * 
     * @return Lista de pacientes curados
     */
    public ArrayList<Paciente> getListaCurados() {
        return this.listaCurados;
    }

    /**
     * Registra a un médico en el hospital
     * 
     * @param m Médico a registrar
     */
    public void registroMedico(Medico m) {
        if (m != null) {
            this.listaMedicos.add(m);
            this.noMedicos++;
        } else {
            System.out.println("No se pudo registrar al médico");
        }
    }

    /**
     * Registra a un enfermero en el hospital
     * 
     * @param e Enfermero a registrar
     */
    public void registroEnfermero(Enfermero e) {
        if (e != null) {
            this.listaEnfermeros.add(e);
            this.noEnfermeros++;
        } else {
            System.out.println("No se pudo registrar al enfermero");
        }
    }

    /**
     * Registra a un paciente en la lista de espera del hospital
     * 
     * @param p Paciente a registrar
     */
    public void registroPaciente(Paciente p) {
        if (p != null) {
            this.listaPacientes.add(p);
            this.noPacientes++;
        } else {
            System.out.println("No se pudo registrar al paciente");
        }
    }

    /**
     * Asigna un paciente en espera a un médico según su especialidad
     * 
     * @param m Médico al que se le asigna el paciente
     */
    public void asignarPaciente(Medico m) {
        if (m == null || m.getNoPacientes() >= 10) {
            return;
        }

        for (int i = 0; i < this.listaPacientes.size(); i++) {
            Paciente p = this.listaPacientes.get(i);

            Map<String, Integer> mapaAux = new HashMap<String, Integer>();
            mapaAux.put(p.getTipoAtencion().toLowerCase(), 1);

            if (mapaAux.containsKey(m.getEspecialidad().toLowerCase()) && m.getNoPacientes() < 10 && p.getEstado() == 'E') {
                m.registroEnSistema(p);
                System.out.println("Paciente " + p.getNombre() + " asignado al médico " + m.getNombre());
                this.listaPacientes.remove(i);
                this.noPacientes--;
                return;
            }
        }
    }

    /**
     * Asigna un paciente en tratamiento a un enfermero según su especialidad
     * 
     * @param e Enfermero al que se le asigna el paciente
     */
    public void asignarPaciente(Enfermero e) {
        if (e == null || e instanceof JefeEnfermeria || e.getNoPacientes() >= 3) {
            return;
        }

        for (int i = 0; i < this.listaPacientes.size(); i++) {
            Paciente p = this.listaPacientes.get(i);

            Map<String, Integer> mapaAux = new HashMap<String, Integer>();
            mapaAux.put(p.getTipoAtencion().toLowerCase(), 1);

            if (mapaAux.containsKey(e.getEspecialidad().toLowerCase()) && e.getNoPacientes() < 3 && p.getEstado() == 'T') {
                e.registroEnSistema(p);
                System.out.println("Paciente " + p.getNombre() + " asignado al enfermero " + e.getNombre());
                this.listaPacientes.remove(i);
                this.noPacientes--;
                return;
            }
        }
    }

    /**
     * Agrega un paciente a la lista de pacientes curados
     * 
     * @param p Paciente curado que se archivará
     */
    public void agregarPacienteCurado(Paciente p) {
        if (p != null) {
            this.listaCurados.add(p);
            System.out.println("Paciente " + p.getNombre() + " ahora está curado");
        } else {
            System.out.println("No se pudo archivar al paciente");
        }
    }

    /**
     * Método principal para ejecutar la simulación del hospital
     * 
     * @param args Argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Sistema hospital = new Sistema();

        System.out.println("Registro de médicos: ");
        System.out.print("¿Cuántos médicos vas a registrar?: ");
        int numMedicos = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < numMedicos; i++) {
            System.out.println("\nDatos del Médico " + (i + 1) + ":");
            System.out.print("Tipo (1. General / 2. Especialista): ");
            int tipo = Integer.parseInt(sc.nextLine());
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            System.out.print("Cédula: ");
            int cedula = Integer.parseInt(sc.nextLine());

            if (tipo == 1) {
                System.out.print("Estudios ordenados: ");
                String estudios = sc.nextLine();
                MedicoGeneral mg = new MedicoGeneral(nombre, cedula, estudios);
                hospital.registroMedico(mg);
            } else {
                System.out.print("Especialidad: ");
                String especialidad = sc.nextLine();
                System.out.print("Prueba especializada: ");
                String prueba = sc.nextLine();
                MedicoEspecialista me = new MedicoEspecialista(nombre, especialidad, cedula, prueba);
                hospital.registroMedico(me);
            }
        }

        System.out.println("\nRegistro de enfermeros: ");
        System.out.print("¿Cuántos enfermeros vas a registrar? ");
        int numEnfermeros = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < numEnfermeros; i++) {
            System.out.println("\nDatos del Enfermero " + (i + 1) + ":");
            System.out.print("Tipo (1. General / 2. Especialista): ");
            int tipo = Integer.parseInt(sc.nextLine());
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            System.out.print("Cédula: ");
            int cedula = Integer.parseInt(sc.nextLine());

            if (tipo == 1) {
                System.out.print("Tipo de cuidado: ");
                String cuidado = sc.nextLine();
                EnfermeroGeneral eg = new EnfermeroGeneral(nombre, cedula, cuidado);
                hospital.registroEnfermero(eg);
            } else {
                System.out.print("Especialidad: ");
                String especialidad = sc.nextLine();
                System.out.print("Procedimiento avanzado: ");
                String procedimiento = sc.nextLine();
                EnfermeroEspecialista ee = new EnfermeroEspecialista(nombre, especialidad, cedula, procedimiento);
                hospital.registroEnfermero(ee);
            }
        }

        System.out.println("\nRegistro de Jefes de Enfermería (2 enfermeros):");
        System.out.println("1. Jefe de Enfermeros Generales:");
        System.out.print("Nombre: ");
        String nomJefe1 = sc.nextLine();
        System.out.print("Cédula: ");
        int cedJefe1 = Integer.parseInt(sc.nextLine());
        System.out.print("Turno de supervisión: ");
        String turnoJefe1 = sc.nextLine();
        JefeEnfermeria jefe1 = new JefeEnfermeria(nomJefe1, "Medicina General", cedJefe1, turnoJefe1);
        hospital.registroEnfermero(jefe1);

        System.out.println("\n2. Jefe de Enfermeros Especialistas:");
        System.out.print("Nombre: ");
        String nomJefe2 = sc.nextLine();
        System.out.print("Cédula: ");
        int cedJefe2 = Integer.parseInt(sc.nextLine());
        System.out.print("Turno de supervisión: ");
        String turnoJefe2 = sc.nextLine();
        JefeEnfermeria jefe2 = new JefeEnfermeria(nomJefe2, "Especialidad", cedJefe2, turnoJefe2);
        hospital.registroEnfermero(jefe2);

        System.out.println("\nSupervisión de guardias de enfermería:");
        jefe1.supervisarGuardia(hospital.getListaEnfermeros());
        jefe2.supervisarGuardia(hospital.getListaEnfermeros());

        System.out.println("\nRegistro de pacientes: ");
        System.out.print("¿Cuántos pacientes vas a registrar? ");
        int numPacientes = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < numPacientes; i++) {
            System.out.println("\nDatos del Paciente " + (i + 1) + ":");
            System.out.print("Tipo (1. General / 2. Especialidad): ");
            int tipo = Integer.parseInt(sc.nextLine());
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            System.out.print("Apellidos: ");
            String apellidos = sc.nextLine();

            Paciente p;
            if (tipo == 1) {
                System.out.print("Motivo de consulta: ");
                String motivo = sc.nextLine();
                PacienteGeneral pg = new PacienteGeneral(nombre, apellidos, motivo);
                pg.mostrarFichaGeneral();
                p = pg;
            } else {
                System.out.print("Especialidad que requiere: ");
                String esp = sc.nextLine();
                PacienteEspecialidad pe = new PacienteEspecialidad(nombre, apellidos, esp);
                pe.mostrarFichaEspecialidad();
                p = pe;
            }

            p.registroEnSistema();
            p.solicitarConsulta();
            hospital.registroPaciente(p);
        }
        sc.close();

        System.out.println(("\n-----------------------------"));
        System.out.println("Hospital: " + hospital.getNombreHospital());

        System.out.println("\nAsignación a médicos: ");
        for (int i = 0; i < hospital.getListaMedicos().size(); i++) {
            Medico m = hospital.getListaMedicos().get(i);
            int pacientesEnEspera = hospital.getListaPacientes().size();
            int pacientesAsignados = 0;

            for (int j = 0; j < pacientesEnEspera; j++) {
                int antes = hospital.getListaPacientes().size();
                hospital.asignarPaciente(m);

                if (antes > hospital.getListaPacientes().size()) {
                    pacientesAsignados++;
                }

                if (antes == hospital.getListaPacientes().size()) {
                    break;
                }
            }
            if (pacientesAsignados == 0) {
                System.out.println("No hay pacientes en espera o está lleno para el médico: " + m.getNombre());
            }
        }

        System.out.println("\nAsignación médica: ");
        for (int i = 0; i < hospital.getListaMedicos().size(); i++) {
            Medico m = hospital.getListaMedicos().get(i);

            m.verListaPacientes();

            while (m.getListaPacientes().size() > 0) {
                Paciente pacienteAtendido = m.solicitarPaciente();
                pacienteAtendido.verTratamiento();
                if (m instanceof MedicoGeneral) {
                    ((MedicoGeneral) m).solicitarEstudiosGenerales();
                } else if (m instanceof MedicoEspecialista) {
                    ((MedicoEspecialista) m).solicitarPruebaEspecializada();
                }
                Paciente pacienteTratado = m.darTratamiento();
                hospital.registroPaciente(pacienteTratado);
            }
        }

        System.out.println("\nAsignación a enfermeros:");
        for (int i = 0; i < hospital.getListaEnfermeros().size(); i++) {
            Enfermero e = hospital.getListaEnfermeros().get(i);
            if (e instanceof JefeEnfermeria) {
                continue;
            }

            int pacientesEnEspera = hospital.getListaPacientes().size();
            int pacientesAsignados = 0;

            for (int j = 0; j < pacientesEnEspera; j++) {
                int antes = hospital.getListaPacientes().size();
                hospital.asignarPaciente(e);

                if (antes > hospital.getListaPacientes().size()) {
                    pacientesAsignados++;
                }

                if (antes == hospital.getListaPacientes().size()) {
                    break;
                }
            }

            if (pacientesAsignados == 0) {
                System.out.println("No hay pacientes en espera o está lleno para el enfermero: " + e.getNombre());
            }
        }

        System.out.println("\nTratamiento de enfermeros: ");
        for (int i = 0; i < hospital.getListaEnfermeros().size(); i++) {
            Enfermero e = hospital.getListaEnfermeros().get(i);
            if (e instanceof JefeEnfermeria) {
                continue;
            }

            e.verListaPacientes();

            while (e.getListaPacientes().size() > 0) {
                Paciente pacienteCurado = e.darTratamiento();
                hospital.agregarPacienteCurado(pacienteCurado);
            }
        }

        System.out.println("\nTotal de pacientes curados archivados: " + hospital.getListaCurados().size());
    }
}
