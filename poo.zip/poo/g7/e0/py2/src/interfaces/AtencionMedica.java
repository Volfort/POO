package poo.g7.e0.py2.src.interfaces;

import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Interfaz para el personal de salud que da tratamiento a los pacientes
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public interface AtencionMedica {
    /**
     * Da el tratamiento al paciente
     * 
     * @return Paciente al que se le dio tratamiento
     */
    Paciente darTratamiento();
}
