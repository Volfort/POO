package poo.g7.e0.py2.src.personal;

import java.util.ArrayList;
import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Representa a un jefe de enfermería encargado de supervisar
 * a los enfermeros en su turno
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class JefeEnfermeria extends Enfermero {
    /**
     * Turno en el que supervisa el jefe de enfermería
     */
    private String turnoSupervision;

    /**
     * Crea un jefe de enfermería con sus datos y turno de supervisión
     * 
     * @param nombre Nombre del jefe de enfermería
     * @param especialidad Sector o tipo de enfermeros que supervisa
     * @param cedula Cédula del jefe de enfermería
     * @param turnoSupervision Turno de supervisión
     */
    public JefeEnfermeria(String nombre, String especialidad, int cedula, String turnoSupervision) {
        super(nombre, especialidad, cedula);
        this.turnoSupervision = turnoSupervision;
    }

    /**
     * Obtiene el turno de supervisión
     * 
     * @return Turno de supervisión
     */
    public String getTurnoSupervision() {
        return this.turnoSupervision;
    }

    /**
     * Muestra los enfermeros a su cargo según su turno y especialidad
     * 
     * @param listaEnfermeros Arreglo de enfermeros del hospital
     */
    public void supervisarGuardia(ArrayList<Enfermero> listaEnfermeros) {
        System.out.println("\nSupervisión de enfermería por el jefe " + getNombre() + " (" + getEspecialidad() + ") en turno " + this.turnoSupervision + ":");
        int total = 0;
        for (int i = 0; i < listaEnfermeros.size(); i++) {
            Enfermero enf = listaEnfermeros.get(i);
            if (this.getEspecialidad().toLowerCase().equals("medicina general") && enf instanceof EnfermeroGeneral) {
                System.out.println("- Enfermero General: " + enf.getNombre());
                total++;
            } else if (!this.getEspecialidad().toLowerCase().equals("medicina general") && enf instanceof EnfermeroEspecialista) {
                System.out.println("- Enfermero Especialista: " + enf.getNombre() + " (" + enf.getEspecialidad() + ")");
                total++;
            }
        }
        if (total == 0) {
            System.out.println("No hay enfermeros registrados para este sector de guardia");
        }
    }

    /**
     * Indica que el jefe de enfermería no da tratamiento directo a pacientes
     * 
     * @return Siempre regresa null
     */
    @Override
    public Paciente darTratamiento() {
        System.out.println("El Jefe de Enfermería supervisa y coordina el área de tratamientos");
        return null;
    }
}
