package poo.g7.e0.py2.src.personal;

import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Representa a un enfermero especialista del hospital que realiza
 * procedimientos avanzados y da tratamiento según su especialidad
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class EnfermeroEspecialista extends Enfermero {
    /**
     * Procedimiento avanzado que realiza el enfermero especialista
     */
    private String procedimientoAvanzado;

    /**
     * Crea un enfermero especialista con sus datos y su procedimiento avanzado
     * 
     * @param nombre Nombre del enfermero
     * @param especialidad Especialidad del enfermero
     * @param cedula Cédula del enfermero
     * @param procedimientoAvanzado Procedimiento avanzado que realiza
     */
    public EnfermeroEspecialista(String nombre, String especialidad, int cedula, String procedimientoAvanzado) {
        super(nombre, especialidad, cedula);
        this.procedimientoAvanzado = procedimientoAvanzado;
    }

    /**
     * Obtiene el procedimiento avanzado que realiza el enfermero
     * 
     * @return Procedimiento avanzado
     */
    public String getProcedimientoAvanzado() {
        return this.procedimientoAvanzado;
    }

    /**
     * Muestra en consola el procedimiento avanzado que realiza el enfermero
     */
    public void aplicarCuidadosIntensivos() {
        System.out.println("El enfermero especialista en " + getEspecialidad() + " (" + getNombre() + ") realiza el procedimiento: " + this.procedimientoAvanzado);
    }

    /**
     * Aplica el procedimiento avanzado y da tratamiento al paciente para curarlo
     * 
     * @return Paciente curado, o null si no hay pacientes
     */
    @Override
    public Paciente darTratamiento() {
        if (getListaPacientes().isEmpty()) {
            System.out.println("Ya no hay pacientes");
            return null;
        }
        aplicarCuidadosIntensivos();
        return super.darTratamiento();
    }
}
