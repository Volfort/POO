package poo.g7.e0.py2.src.personal;

import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Representa a un médico especialista del hospital que atiende consultas
 * de su especialidad y pide pruebas especializadas
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class MedicoEspecialista extends Medico {
    /**
     * Prueba especializada que pide el médico
     */
    private String pruebaEspecializada;

    /**
     * Crea un médico especialista con sus datos y la prueba que pide
     * 
     * @param nombre Nombre del médico especialista
     * @param especialidad Especialidad del médico
     * @param cedula Cédula del médico
     * @param pruebaEspecializada Prueba que pide el médico
     */
    public MedicoEspecialista(String nombre, String especialidad, int cedula, String pruebaEspecializada) {
        super(nombre, especialidad, cedula);
        this.pruebaEspecializada = pruebaEspecializada;
    }

    /**
     * Obtiene la prueba especializada que pide el médico
     * 
     * @return Prueba especializada
     */
    public String getPruebaEspecializada() {
        return this.pruebaEspecializada;
    }

    /**
     * Muestra en consola la prueba especializada que pide el médico
     */
    public void solicitarPruebaEspecializada() {
        System.out.println("El médico especialista en " + getEspecialidad() + " (" + getNombre() + ") solicita la prueba: " + this.pruebaEspecializada);
    }

    /**
     * Da consulta de su especialidad y cambia el estado del paciente
     * 
     * @param p Paciente a atender
     */
    @Override
    public void darConsulta(Paciente p) {
        if (p != null) {
            p.setEstado('C');
            System.out.println("El médico especialista en " + getEspecialidad() + " (" + getNombre() + ") atiende al paciente: " + p.getNombre());
        } else {
            System.out.println("No se encontro al paciente");
        }
    }
}
