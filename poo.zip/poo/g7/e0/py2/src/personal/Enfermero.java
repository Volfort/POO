package poo.g7.e0.py2.src.personal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import poo.g7.e0.py2.src.interfaces.AtencionMedica;
import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Clase base para los enfermeros del hospital que se encargan de
 * dar tratamiento a los pacientes
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public abstract class Enfermero implements AtencionMedica {
    /**
     * Nombre del enfermero
     */
    private String nombre;

    /**
     * Especialidad del enfermero
     */
    private String especialidad;

    /**
     * Cédula profesional del enfermero
     */
    private int cedula;

    /**
     * Número de pacientes que tiene asignados
     */
    private int noPacientes;

    /**
     * Arreglo de pacientes asignados al enfermero
     */
    private ArrayList<Paciente> listaPacientes;

    /**
     * Crea un enfermero con su nombre, especialidad y cédula
     * 
     * @param nombre Nombre del enfermero
     * @param especialidad Especialidad del enfermero
     * @param cedula Cédula del enfermero
     */
    public Enfermero(String nombre, String especialidad, int cedula) {
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.cedula = cedula;
        this.noPacientes = 0;
        this.listaPacientes = new ArrayList<Paciente>();
    }

    /**
     * Obtiene el nombre del enfermero
     * 
     * @return Nombre del enfermero
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene la especialidad del enfermero
     * 
     * @return Especialidad del enfermero
     */
    public String getEspecialidad() {
        return this.especialidad;
    }

    /**
     * Obtiene la cédula del enfermero
     * 
     * @return Cédula del enfermero
     */
    public int getCedula() {
        return this.cedula;
    }

    /**
     * Obtiene el número de pacientes asignados al enfermero
     * 
     * @return Número de pacientes
     */
    public int getNoPacientes() {
        return this.noPacientes;
    }

    /**
     * Obtiene el arreglo de pacientes asignados al enfermero
     * 
     * @return Arreglo de pacientes
     */
    public ArrayList<Paciente> getListaPacientes() {
        return this.listaPacientes;
    }

    /**
     * Agrega un paciente a la lista del enfermero si tiene menos de 3
     * 
     * @param p Paciente a registrar
     */
    public void registroEnSistema(Paciente p) {
        if (p != null && this.noPacientes < 3) {
            this.listaPacientes.add(p);
            this.noPacientes++;
        } else {
            System.out.println("No se encontro al paciente o la lista esta llena");
        }
    }

    /**
     * Da tratamiento al primer paciente de la lista, lo marca como curado y lo quita de su lista
     * 
     * @return Paciente curado, o null si no hay pacientes
     */
    @Override
    public Paciente darTratamiento() {
        if (this.listaPacientes.isEmpty()) {
            System.out.println("Ya no hay pacientes");
            return null;
        } else {
            Paciente p = this.listaPacientes.get(0);
            p.setEstado('A');
            System.out.println("Dando tratamiento a: " + p.getNombre());
            p.verTratamiento();

            this.listaPacientes.remove(0);
            this.noPacientes--;

            return p;
        }
    }

    /**
     * Muestra la lista de pacientes del enfermero en orden alfabético
     */
    public void verListaPacientes() {
        System.out.println("\nLista de pacientes del enfermero :" + this.nombre);

        if (this.listaPacientes.isEmpty()) {
            System.out.println("No hay pacientes que mostrar");
            return;
        }

        Map<String, Integer> mapa = new HashMap<>();

        for (int i = 0; i < this.listaPacientes.size(); i++) {
            Paciente p = this.listaPacientes.get(i);
            String infoPaciente = p.getApellidos() + " " + p.getNombre() + " - Especialidad: " + p.getTipoAtencion() + " (" + i + ")";
            mapa.put(infoPaciente, 1);
        }

        Set<String> llaves = mapa.keySet();
        TreeSet<String> llavesOrd = new TreeSet<>(llaves);

        ArrayList<String> listaAscendente = new ArrayList<>();
        for (String llave : llavesOrd) {
            listaAscendente.add(llave);
        }

        for (int i = listaAscendente.size() - 1; i >= 0; i--) {
            System.out.println(listaAscendente.get(i));
        }
    }
}
