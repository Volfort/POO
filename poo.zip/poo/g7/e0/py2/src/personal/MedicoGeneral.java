package poo.g7.e0.py2.src.personal;

import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Representa a un médico general del hospital que atiende consultas
 * de medicina general y pide estudios generales
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class MedicoGeneral extends Medico {
    /**
     * Estudios generales que pide el médico
     */
    private String estudiosOrdenados;

    /**
     * Crea un médico general con sus datos y estudios que pide
     * 
     * @param nombre Nombre del médico general
     * @param cedula Cédula del médico
     * @param estudiosOrdenados Estudios generales que pide
     */
    public MedicoGeneral(String nombre, int cedula, String estudiosOrdenados) {
        super(nombre, "Medicina General", cedula);
        this.estudiosOrdenados = estudiosOrdenados;
    }

    /**
     * Obtiene los estudios generales que pide el médico
     * 
     * @return Estudios generales
     */
    public String getEstudiosOrdenados() {
        return this.estudiosOrdenados;
    }

    /**
     * Muestra en consola los estudios generales que pide el médico
     */
    public void solicitarEstudiosGenerales() {
        System.out.println("El médico general " + getNombre() + " solicita los estudios: " + this.estudiosOrdenados);
    }

    /**
     * Da consulta de medicina general y cambia el estado del paciente
     * 
     * @param p Paciente a atender
     */
    @Override
    public void darConsulta(Paciente p) {
        if (p != null) {
            p.setEstado('C');
            System.out.println("El médico general " + getNombre() + " atiende al paciente: " + p.getNombre());
        } else {
            System.out.println("No se encontro al paciente");
        }
    }
}
