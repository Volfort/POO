package poo.g7.e0.py2.src.personal;

import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Representa a un enfermero general del hospital que aplica cuidados
 * generales y da tratamiento a los pacientes
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class EnfermeroGeneral extends Enfermero {
    /**
     * Tipo de cuidado general que da el enfermero
     */
    private String tipoCuidado;

    /**
     * Crea un enfermero general con sus datos y el tipo de cuidado que aplica
     * 
     * @param nombre Nombre del enfermero
     * @param cedula Cédula del enfermero
     * @param tipoCuidado Tipo de cuidado que aplica
     */
    public EnfermeroGeneral(String nombre, int cedula, String tipoCuidado) {
        super(nombre, "Medicina General", cedula);
        this.tipoCuidado = tipoCuidado;
    }

    /**
     * Obtiene el tipo de cuidado general
     * 
     * @return Tipo de cuidado
     */
    public String getTipoCuidado() {
        return this.tipoCuidado;
    }

    /**
     * Muestra en consola los cuidados generales que aplica el enfermero
     */
    public void aplicarCuidadosGenerales() {
        System.out.println("El enfermero general " + getNombre() + " aplica cuidados: " + this.tipoCuidado);
    }

    /**
     * Aplica los cuidados generales y da tratamiento al paciente para curarlo
     * 
     * @return Paciente curado, o null si no hay pacientes
     */
    @Override
    public Paciente darTratamiento() {
        if (getListaPacientes().isEmpty()) {
            System.out.println("Ya no hay pacientes");
            return null;
        }
        aplicarCuidadosGenerales();
        return super.darTratamiento();
    }
}
