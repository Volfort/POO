package poo.g7.e0.py2.src.personal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import poo.g7.e0.py2.src.interfaces.AtencionMedica;
import poo.g7.e0.py2.src.pacientes.Paciente;

/**
 * Clase base para los medicos del hospital que atiende consultas
 * y da tratamiento a los pacientes
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public abstract class Medico implements AtencionMedica {
    /**
     * Nombre del médico
     */
    private String nombre;

    /**
     * Especialidad del médico
     */
    private String especialidad;

    /**
     * Cédula profesional del médico
     */
    private int cedula;

    /**
     * Número de pacientes que tiene asignados
     */
    private int noPacientes;

    /**
     * Arreglo de pacientes asignados al médico
     */
    private ArrayList<Paciente> listaPacientes;

    /**
     * Crea un médico con su nombre, especialidad y cédula
     * 
     * @param nombre Nombre del médico
     * @param especialidad Especialidad del médico
     * @param cedula Cédula del médico
     */
    public Medico(String nombre, String especialidad, int cedula) {
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.cedula = cedula;
        this.noPacientes = 0;
        this.listaPacientes = new ArrayList<Paciente>();
    }

    /**
     * Obtiene el nombre del médico
     * 
     * @return Nombre del médico
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene la especialidad del médico
     * 
     * @return Especialidad del médico
     */
    public String getEspecialidad() {
        return this.especialidad;
    }

    /**
     * Obtiene la cédula del médico
     * 
     * @return Cédula del médico
     */
    public int getCedula() {
        return this.cedula;
    }

    /**
     * Obtiene el número de pacientes asignados al médico
     * 
     * @return Número de pacientes
     */
    public int getNoPacientes() {
        return this.noPacientes;
    }

    /**
     * Obtiene el arreglo de pacientes asignados al médico
     * 
     * @return Arreglo de pacientes
     */
    public ArrayList<Paciente> getListaPacientes() {
        return this.listaPacientes;
    }

    /**
     * Agrega un paciente a la lista del médico si tiene menos de 10
     * 
     * @param p Paciente a registrar
     */
    public void registroEnSistema(Paciente p) {
        if (p != null && this.noPacientes < 10) {
            this.listaPacientes.add(p);
            this.noPacientes++;
        } else {
            System.out.println("No se encontro al paciente o la lista esta llena");
        }
    }

    /**
     * Llama al primer paciente de la lista para darle consulta
     * 
     * @return Paciente llamado, o null si no hay o ya está ocupado
     */
    public Paciente solicitarPaciente() {
        if (this.listaPacientes.isEmpty()) {
            System.out.println("Ya no hay pacientes");
            return null;
        }

        Paciente pacienteTurno = this.listaPacientes.get(0);

        if (pacienteTurno.getEstado() == 'C') {
            System.out.println("El medico " + this.nombre + " ya esta ocupado con " + pacienteTurno.getNombre());
            return null;
        } else {
            darConsulta(pacienteTurno);
            return pacienteTurno;
        }
    }

    /**
     * Da consulta al paciente y cambia su estado
     * 
     * @param p Paciente a consultar
     */
    public abstract void darConsulta(Paciente p);

    /**
     * Da tratamiento al paciente en consulta y lo quita de su lista
     * 
     * @return Paciente tratado, o null si no hay
     */
    @Override
    public Paciente darTratamiento() {
        if (this.listaPacientes.isEmpty()) {
            System.out.println("Ya no hay pacientes");
            return null;
        }

        Paciente p = this.listaPacientes.get(0);

        if (p.getEstado() != 'C') {
            System.out.println("El paciente no esta en consulta.");
            return null;
        }

        p.setEstado('T');
        System.out.println("El medico indico tratamiento a: " + p.getNombre());

        this.listaPacientes.remove(0);
        this.noPacientes--;

        return p;
    }

    /**
     * Muestra la lista de pacientes del médico en orden alfabético
     */
    public void verListaPacientes() {
        System.out.println("\nLista de pacientes ordenada del medico :" + this.nombre);

        if (this.listaPacientes.isEmpty()) {
            System.out.println("No hay pacientes que mostrar");
            return;
        }

        Map<String, Integer> mapa = new HashMap<>();

        for (int i = 0; i < this.listaPacientes.size(); i++) {
            Paciente p = this.listaPacientes.get(i);
            String infoPaciente = p.getApellidos() + " " + p.getNombre() + " - Especialidad: " + p.getTipoAtencion() + " (" + i + ")";
            mapa.put(infoPaciente, 1);
        }

        Set<String> llaves = mapa.keySet();
        TreeSet<String> llavesOrd = new TreeSet<>(llaves);

        ArrayList<String> listaAscendente = new ArrayList<>();
        for (String llave : llavesOrd) {
            listaAscendente.add(llave);
        }

        for (int i = listaAscendente.size() - 1; i >= 0; i--) {
            System.out.println(listaAscendente.get(i));
        }
    }
}
