package mx.unam.die.poo.g7.practica_12_13.src;

/**
 * Hilo que representa a un cliente que llega al restaurante y realiza un pedido
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Cliente extends Thread {

    /**
     * Identificador del cliente
     */
    private int id;

    /**
     * Platillo que ordenará el cliente
     */
    private String platillo;

    /**
     * Cola compartida donde se deposita el pedido
     */
    private ColaPedidos cola;

    /**
     * Vista para imprimir los eventos del cliente
     */
    private VistaRestaurante vista;

    /**
     * Constructor que inicializa los datos del cliente y sus recursos compartidos
     *
     * @param id Identificador del cliente
     * @param platillo Nombre del platillo a ordenar
     * @param cola Cola compartida de pedidos
     * @param vista Vista de consola del restaurante
     */
    public Cliente(int id, String platillo, ColaPedidos cola, VistaRestaurante vista) {
        this.id = id;
        this.platillo = platillo;
        this.cola = cola;
        this.vista = vista;
    }

    /**
     * Ejecuta el hilo del cliente simulando la toma de decisión y el envío del pedido
     */
    @Override
    public void run() {
        try {
            Thread.sleep(200);
            Pedido pedido = new Pedido(id, platillo);
            vista.mostrarMensaje("Cliente " + id + " realizó su pedido: " + platillo);
            cola.agregarPedido(pedido);
        } catch (InterruptedException e) {
            vista.mostrarMensaje("Cliente " + id + " fue interrumpido");
        }
    }
}
