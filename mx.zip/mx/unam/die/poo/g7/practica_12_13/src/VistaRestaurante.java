package mx.unam.die.poo.g7.practica_12_13.src;

/**
 * Vista de consola del patrón MVC encargada de mostrar mensajes sincronizados
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class VistaRestaurante {

    /**
     * Muestra un mensaje en la salida estándar de forma sincronizada
     *
     * @param mensaje Texto a imprimir en consola
     */
    public synchronized void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
