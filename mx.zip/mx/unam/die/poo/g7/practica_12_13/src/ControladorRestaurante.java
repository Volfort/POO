package mx.unam.die.poo.g7.practica_12_13.src;

/**
 * Controlador del patrón MVC que coordina el modelo, la vista y el ciclo de vida de los hilos
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class ControladorRestaurante {

    /**
     * Cola compartida de pedidos del modelo
     */
    private ColaPedidos cola;

    /**
     * Cocina compartida del modelo
     */
    private Cocina cocina;

    /**
     * Vista de consola para desplegar el avance de la simulación
     */
    private VistaRestaurante vista;

    /**
     * Constructor que conecta el modelo y la vista en el controlador
     *
     * @param cola Cola compartida de pedidos
     * @param cocina Cocina compartida del restaurante
     * @param vista Vista de consola del restaurante
     */
    public ControladorRestaurante(ColaPedidos cola, Cocina cocina, VistaRestaurante vista) {
        this.cola = cola;
        this.cocina = cocina;
        this.vista = vista;
    }

    /**
     * Inicia los hilos de meseros y clientes, espera su finalización y cierra la cola
     */
    public void iniciarSimulacion() {
        vista.mostrarMensaje("Iniciando simulación del restaurante...");

        Mesero mesero1 = new Mesero("Mesero 1", cola, cocina, vista);
        Mesero mesero2 = new Mesero("Mesero 2", cola, cocina, vista);
        mesero1.start();
        mesero2.start();

        String[] platillos = {"Tacos", "Enchiladas", "Pozole", "Chilaquiles", "Quesadillas"};
        Cliente[] clientes = new Cliente[platillos.length];

        for (int i = 0; i < platillos.length; i++) {
            clientes[i] = new Cliente(i + 1, platillos[i], cola, vista);
            clientes[i].start();
        }

        try {
            for (int i = 0; i < clientes.length; i++) {
                clientes[i].join();
            }

            cola.cerrar();

            mesero1.join();
            mesero2.join();
        } catch (InterruptedException e) {
            vista.mostrarMensaje("La simulación fue interrumpida");
        }

        vista.mostrarMensaje("Todos los pedidos fueron atendidos. Restaurante cerrado.");
    }
}
