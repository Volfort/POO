package mx.unam.die.poo.g7.practica_12_13.src;

/**
 * Representa un pedido realizado por un cliente con su platillo
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Pedido {

    /**
     * Identificador numérico del cliente
     */
    private int cliente;

    /**
     * Nombre del platillo solicitado
     */
    private String platillo;

    /**
     * Constructor que inicializa el pedido con el cliente y el platillo
     *
     * @param cliente Identificador del cliente que realiza el pedido
     * @param platillo Nombre del platillo pedido
     */
    public Pedido(int cliente, String platillo) {
        this.cliente = cliente;
        this.platillo = platillo;
    }

    /**
     * Obtiene el identificador del cliente
     *
     * @return Entero con el identificador del cliente
     */
    public int getCliente() {
        return this.cliente;
    }

    /**
     * Obtiene el nombre del platillo
     *
     * @return Cadena con el nombre del platillo
     */
    public String getPlatillo() {
        return this.platillo;
    }
}
