package mx.unam.die.poo.g7.practica_12_13.src;

/**
 * Clase principal que arma los componentes MVC e inicia la simulación del restaurante
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Restaurante {

    /**
     * Método principal que instancia la vista, el modelo y el controlador
     *
     * @param args Argumentos por línea de comandos
     */
    public static void main(String[] args) {
        VistaRestaurante vista = new VistaRestaurante();
        ColaPedidos cola = new ColaPedidos();
        Cocina cocina = new Cocina(vista);
        ControladorRestaurante controlador = new ControladorRestaurante(cola, cocina, vista);

        controlador.iniciarSimulacion();
    }
}
