package mx.unam.die.poo.g7.practica_12_13.src;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Cola sincronizada compartida para almacenar y entregar pedidos entre clientes y meseros
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class ColaPedidos {

    /**
     * Estructura FIFO que guarda los pedidos pendientes
     */
    private Queue<Pedido> pedidos;

    /**
     * Bandera que indica si ya no llegarán más pedidos
     */
    private boolean cerrado;

    /**
     * Constructor que inicializa la cola vacía y abierta
     */
    public ColaPedidos() {
        this.pedidos = new LinkedList<>();
        this.cerrado = false;
    }

    /**
     * Agrega un pedido a la cola y despierta a los meseros en espera
     *
     * @param pedido Pedido realizado por un cliente
     */
    public synchronized void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
        notifyAll();
    }

    /**
     * Toma el siguiente pedido de la cola o espera hasta que llegue uno o cierre el restaurante
     *
     * @return Siguiente pedido disponible o null si la cola está vacía y cerrada
     * @throws InterruptedException Si el hilo es interrumpido mientras espera
     */
    public synchronized Pedido tomarPedido() throws InterruptedException {
        while (pedidos.isEmpty() && !cerrado) {
            wait();
        }
        if (pedidos.isEmpty() && cerrado) {
            return null;
        }
        return pedidos.poll();
    }

    /**
     * Marca la cola como cerrada y despierta a todos los meseros dormidos
     */
    public synchronized void cerrar() {
        cerrado = true;
        notifyAll();
    }
}
