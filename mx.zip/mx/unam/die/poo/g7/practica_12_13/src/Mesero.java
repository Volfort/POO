package mx.unam.die.poo.g7.practica_12_13.src;

/**
 * Hilo que representa a un mesero que toma pedidos de la cola y los lleva a la cocina
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Mesero extends Thread {

    /**
     * Nombre del mesero
     */
    private String nombre;

    /**
     * Cola compartida de donde obtiene los pedidos
     */
    private ColaPedidos cola;

    /**
     * Cocina compartida donde se preparan los pedidos
     */
    private Cocina cocina;

    /**
     * Vista para imprimir los eventos del mesero
     */
    private VistaRestaurante vista;

    /**
     * Constructor que inicializa al mesero con su nombre y recursos compartidos
     *
     * @param nombre Nombre identificador del mesero
     * @param cola Cola compartida de pedidos
     * @param cocina Cocina compartida del restaurante
     * @param vista Vista de consola del restaurante
     */
    public Mesero(String nombre, ColaPedidos cola, Cocina cocina, VistaRestaurante vista) {
        this.nombre = nombre;
        this.cola = cola;
        this.cocina = cocina;
        this.vista = vista;
    }

    /**
     * Ejecuta el turno del mesero atendiendo pedidos hasta que la cola se cierre
     */
    @Override
    public void run() {
        try {
            while (true) {
                Pedido pedido = cola.tomarPedido();
                if (pedido == null) {
                    break;
                }
                vista.mostrarMensaje(nombre + " tomó el pedido de " + pedido.getPlatillo()
                        + " del Cliente " + pedido.getCliente());
                cocina.prepararPedido(pedido, nombre);
            }
            vista.mostrarMensaje(nombre + " terminó su turno");
        } catch (InterruptedException e) {
            vista.mostrarMensaje(nombre + " fue interrumpido");
        }
    }
}
