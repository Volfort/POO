package mx.unam.die.poo.g7.practica_12_13.src;

/**
 * Simula la cocina compartida del restaurante que prepara un pedido a la vez
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Cocina {

    /**
     * Vista utilizada para mostrar el estado de preparación
     */
    private VistaRestaurante vista;

    /**
     * Constructor que asocia la vista a la cocina
     *
     * @param vista Vista de consola del restaurante
     */
    public Cocina(VistaRestaurante vista) {
        this.vista = vista;
    }

    /**
     * Prepara de forma sincronizada el pedido llevado por un mesero
     *
     * @param pedido Pedido a preparar
     * @param nombreMesero Nombre del mesero que entregó el pedido
     * @throws InterruptedException Si el hilo es interrumpido durante la preparación
     */
    public synchronized void prepararPedido(Pedido pedido, String nombreMesero) throws InterruptedException {
        vista.mostrarMensaje("Cocina preparando " + pedido.getPlatillo()
                + " del Cliente " + pedido.getCliente() + " (atendido por " + nombreMesero + ")");
        Thread.sleep(600);
        vista.mostrarMensaje("Cocina terminó " + pedido.getPlatillo()
                + " del Cliente " + pedido.getCliente());
    }
}
