package mx.unam.die.poo.g7.practica_11.src;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 * Lee el contenido de un archivo de texto y cuenta el total de palabras
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class ArchivoTexto {

    /**
     * Texto leído del archivo
     */
    private String contenido;

    /**
     * Cantidad total de palabras encontradas en el texto
     */
    private int totalPalabras;

    /**
     * Constructor que inicializa el contenido vacío y el contador en cero
     */
    public ArchivoTexto() {
        this.contenido = "";
        this.totalPalabras = 0;
    }

    /**
     * Lee el archivo texto.txt como bytes, lo convierte a texto y cuenta sus palabras
     *
     * @throws IOException Si ocurre un error al abrir o leer el archivo
     */
    public void leerArchivo() throws IOException {
        byte[] buffer = new byte[1024];

        FileInputStream fis = new FileInputStream("texto.txt");
        int nbytes = fis.read(buffer, 0, 1024);
        fis.close();

        if (nbytes > 0) {
            this.contenido = new String(buffer, 0, nbytes);
        } else {
            this.contenido = "";
        }

        StringTokenizer st = new StringTokenizer(this.contenido);
        this.totalPalabras = st.countTokens();
    }

    /**
     * Obtiene el contenido leído del archivo
     *
     * @return Cadena con el texto del archivo
     */
    public String getContenido() {
        return this.contenido;
    }

    /**
     * Obtiene el número total de palabras contadas
     *
     * @return Entero con el total de palabras
     */
    public int getTotalPalabras() {
        return this.totalPalabras;
    }
}
