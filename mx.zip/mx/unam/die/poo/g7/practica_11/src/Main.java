package mx.unam.die.poo.g7.practica_11.src;

import java.awt.BorderLayout;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Clase principal que lee el archivo de texto y muestra su contenido y total de palabras en una ventana Swing
 *
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Main {

    /**
     * Método principal que ejecuta la lectura del archivo y construye la interfaz gráfica
     *
     * @param args Argumentos por línea de comandos
     */
    public static void main(String[] args) {
        ArchivoTexto archivo = new ArchivoTexto();

        try {
            archivo.leerArchivo();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
            return;
        }

        JFrame ventana = new JFrame("Lector de archivo .txt");
        ventana.setSize(500, 350);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);

        JTextArea cuadroTexto = new JTextArea(archivo.getContenido());
        cuadroTexto.setEditable(false);
        cuadroTexto.setLineWrap(true);
        cuadroTexto.setWrapStyleWord(true);

        JScrollPane scroll = new JScrollPane(cuadroTexto);
        JLabel etiquetaPalabras = new JLabel("Total de palabras: " + archivo.getTotalPalabras());

        ventana.add(scroll, BorderLayout.CENTER);
        ventana.add(etiquetaPalabras, BorderLayout.SOUTH);
        ventana.setVisible(true);
    }
}
