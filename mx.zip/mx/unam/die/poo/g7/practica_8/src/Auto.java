package mx.unam.die.poo.g7.practica_8.src;

/**
 * Clase que representa un automovil y calcula su huella de carbono
 * en funcion de los kilometros recorridos y su rendimiento de combustible
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Auto implements HuellaCarbono {

    private String modelo;
    private double kilometrosRecorridos;
    private double rendimientoKml;

    /**
     * Constructor que inicializa los atributos del automovil
     * 
     * @param modelo Marca y modelo del vehiculo
     * @param kilometrosRecorridos Distancia recorrida en kilometros
     * @param rendimientoKml Rendimiento de combustible en kilometros por litro (km/l)
     */
    public Auto(String modelo, double kilometrosRecorridos, double rendimientoKml) {
        this.modelo = modelo;
        this.kilometrosRecorridos = kilometrosRecorridos;
        this.rendimientoKml = rendimientoKml;
    }

    /**
     * Obtiene el modelo del automovil
     * 
     * @return Retorna el modelo del auto
     */
    public String getModelo() {
        return this.modelo;
    }

    /**
     * Obtiene los kilometros recorridos
     * 
     * @return Retorna la distancia en kilometros
     */
    public double getKilometrosRecorridos() {
        return this.kilometrosRecorridos;
    }

    /**
     * Obtiene el rendimiento de combustible
     * 
     * @return Retorna el rendimiento en km/l
     */
    public double getRendimientoKml() {
        return this.rendimientoKml;
    }

    /**
     * Calcula los litros de combustible consumidos durante el recorrido
     * 
     * @return Litros consumidos
     */
    public double getLitrosConsumidos() {
        if (this.rendimientoKml <= 0) {
            return 0.0;
        }
        return this.kilometrosRecorridos / this.rendimientoKml;
    }

    /**
     * Comportamiento propio y exclusivo que simula el accionamiento del claxon
     */
    public void tocarClaxon() {
        System.out.println("El auto " + this.modelo + " suena: Beep beep!");
    }

    /**
     * Calcula la huella de carbono generada por el automovil.
     * Determina los litros consumidos (km / rendimiento) y multiplica por
     * el factor de emision de gasolina de 2.31 kg CO2 por litro quemado
     * 
     * @return Retorna los kilogramos de CO2 generados
     */
    @Override
    public double getHuellaCarbono() {
        return getLitrosConsumidos() * 2.31;
    }

    /**
     * Representacion textual para identificar al automovil
     * 
     * @return Retorna los detalles de identificacion del auto
     */
    @Override
    public String toString() {
        return "Auto: " + this.modelo + " | Distancia: " + this.kilometrosRecorridos + " km | Combustible: " + String.format("%.2f", getLitrosConsumidos()) + " L | Rendimiento: " + this.rendimientoKml + " km/l";
    }
}
