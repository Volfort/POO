package mx.unam.die.poo.g7.practica_8.src;

/**
 * Clase que representa una bicicleta y calcula su huella de carbono estimada
 * asociada al desgaste de componentes y energia del ciclista
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Bicicleta implements HuellaCarbono {

    private String marca;
    private int numeroVelocidades;
    private double kilometrosPedaleados;

    /**
     * Constructor que inicializa los atributos de la bicicleta
     * 
     * @param marca Marca o tipo de la bicicleta
     * @param numeroVelocidades Cantidad de velocidades
     * @param kilometrosPedaleados Distancia pedaleada en kilometros
     */
    public Bicicleta(String marca, int numeroVelocidades, double kilometrosPedaleados) {
        this.marca = marca;
        this.numeroVelocidades = numeroVelocidades;
        this.kilometrosPedaleados = kilometrosPedaleados;
    }

    /**
     * Obtiene la marca de la bicicleta
     * 
     * @return Retorna la marca de la bicicleta
     */
    public String getMarca() {
        return this.marca;
    }

    /**
     * Obtiene el numero de velocidades
     * 
     * @return Retorna el numero de velocidades
     */
    public int getNumeroVelocidades() {
        return this.numeroVelocidades;
    }

    /**
     * Obtiene los kilometros pedaleados
     * 
     * @return Retorna los kilometros pedaleados
     */
    public double getKilometrosPedaleados() {
        return this.kilometrosPedaleados;
    }

    /**
     * Comportamiento propio y exclusivo que simula el cambio de marcha en la bicicleta
     * 
     * @param nuevaVelocidad Numero de marcha seleccionada
     */
    public void cambiarVelocidad(int nuevaVelocidad) {
        if (nuevaVelocidad > 0 && nuevaVelocidad <= this.numeroVelocidades) {
            System.out.println("Se cambio a la velocidad " + nuevaVelocidad + " en la bicicleta " + this.marca);
        } else {
            System.out.println("Velocidad invalida para la bicicleta " + this.marca);
        }
    }

    /**
     * Calcula la huella de carbono generada por la bicicleta.
     * Considera un factor indirecto de 0.005 kg CO2e por km derivado
     * del desgaste de componentes y consumo calorico
     * 
     * @return Retorna los kilogramos de CO2 equivalente generados
     */
    @Override
    public double getHuellaCarbono() {
        return this.kilometrosPedaleados * 0.005;
    }

    /**
     * Representacion textual para identificar a la bicicleta
     * 
     * @return Retorna los detalles de identificacion de la bicicleta
     */
    @Override
    public String toString() {
        return "Bicicleta: " + this.marca + " | Velocidades: " + this.numeroVelocidades + " | Distancia pedaleada: " + this.kilometrosPedaleados + " km";
    }
}
