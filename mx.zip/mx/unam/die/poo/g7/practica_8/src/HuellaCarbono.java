package mx.unam.die.poo.g7.practica_8.src;

/**
 * Interfaz que define el contrato para el calculo de la huella de carbono
 * en entidades no relacionadas mediante herencia
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public interface HuellaCarbono {

    /**
     * Calcula y retorna la huella de carbono generada por la entidad
     * 
     * @return Retorna la huella de carbono en kilogramos de CO2 equivalente (kg CO2e)
     */
    double getHuellaCarbono();
}
