package mx.unam.die.poo.g7.practica_8.src;

import java.util.ArrayList;

/**
 * Clase principal que demuestra el polimorfismo mediante la interfaz HuellaCarbono,
 * almacenando referencias de Edificio, Auto y Bicicleta en un ArrayList
 * e invocando polimorficamente el calculo de la huella de carbono de cada objeto
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Main {

    /**
     * Constructor de la clase principal
     */
    public Main() {
    }

    /**
     * Metodo principal que ejecuta la creacion y el recorrido polimorfico de objetos
     * 
     * @param args Argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        Edificio edificio = new Edificio("Torre de Ingenieria", 12500.0, 10);
        Auto auto = new Auto("Nissan Versa 2022", 1500.0, 14.5);
        Bicicleta bicicleta = new Bicicleta("Mercurio Ranger Rodada 29", 21, 320.0);

        System.out.println("=== Demostracion de Comportamientos Exclusivos ===");
        edificio.encenderLucesPiso(4);
        auto.tocarClaxon();
        bicicleta.cambiarVelocidad(7);

        System.out.println("\n=== Calculo Polimorfico de Huella de Carbono ===");
        ArrayList<HuellaCarbono> listaEmisiones = new ArrayList<HuellaCarbono>();
        listaEmisiones.add(edificio);
        listaEmisiones.add(auto);
        listaEmisiones.add(bicicleta);

        for (HuellaCarbono entidad : listaEmisiones) {
            System.out.println("----------------------------------------------------------------");
            System.out.println("Identificacion: " + entidad.toString());
            System.out.println("Huella de Carbono calculada: " + String.format("%.2f", entidad.getHuellaCarbono()) + " kg CO2e");
        }
        System.out.println("----------------------------------------------------------------");
    }
}
