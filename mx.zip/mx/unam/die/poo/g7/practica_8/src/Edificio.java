package mx.unam.die.poo.g7.practica_8.src;

/**
 * Clase que representa un edificio y calcula su huella de carbono
 * a partir de su consumo de energia electrica
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Edificio implements HuellaCarbono {

    private String nombre;
    private double consumoElectricoKwh;
    private int numeroPisos;

    /**
     * Constructor que inicializa los atributos del edificio
     * 
     * @param nombre Nombre o identificador del edificio
     * @param consumoElectricoKwh Consumo electrico mensual en kilowatt-hora (kWh)
     * @param numeroPisos Numero de niveles del edificio
     */
    public Edificio(String nombre, double consumoElectricoKwh, int numeroPisos) {
        this.nombre = nombre;
        this.consumoElectricoKwh = consumoElectricoKwh;
        this.numeroPisos = numeroPisos;
    }

    /**
     * Obtiene el nombre del edificio
     * 
     * @return Retorna el nombre del edificio
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene el consumo electrico en kWh
     * 
     * @return Retorna el consumo electrico
     */
    public double getConsumoElectricoKwh() {
        return this.consumoElectricoKwh;
    }

    /**
     * Obtiene el numero de pisos del edificio
     * 
     * @return Retorna el numero de pisos
     */
    public int getNumeroPisos() {
        return this.numeroPisos;
    }

    /**
     * Comportamiento propio y exclusivo que simula la activacion de luces en un piso
     * 
     * @param piso Nivel del edificio a encender
     */
    public void encenderLucesPiso(int piso) {
        if (piso > 0 && piso <= this.numeroPisos) {
            System.out.println("Luces encendidas en el piso " + piso + " del edificio " + this.nombre);
        } else {
            System.out.println("El piso " + piso + " no existe en el edificio " + this.nombre);
        }
    }

    /**
     * Calcula la huella de carbono generada por el edificio.
     * Considera un factor de emision electrico de 0.438 kg CO2e por kWh consumido
     * 
     * @return Retorna los kilogramos de CO2 equivalente generados
     */
    @Override
    public double getHuellaCarbono() {
        return this.consumoElectricoKwh * 0.438;
    }

    /**
     * Representacion textual para identificar al edificio
     * 
     * @return Retorna los detalles de identificacion del edificio
     */
    @Override
    public String toString() {
        return "Edificio: " + this.nombre + " | Pisos: " + this.numeroPisos + " | Consumo electrico: " + this.consumoElectricoKwh + " kWh";
    }
}
