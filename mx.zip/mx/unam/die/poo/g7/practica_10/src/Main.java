package mx.unam.die.poo.g7.practica_10.src;

import java.util.Scanner;

/**
 * Clase que gestiona la interacción con el usuario a través de la consola, lee los datos
 * de entrada y demuestra la captura polimórfica de diversas excepciones mediante la superclase Exception
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Main {

    /**
     * Solicita dos números al usuario, instancia la operación division y muestra
     * la captura de diversas excepciones con catch
     * 
     * @param args Argumentos por línea de comandos
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Ingresa el numerador:");
            String entrada1 = scanner.nextLine();
            int num1 = Integer.parseInt(entrada1);

            System.out.print("Ingresa el denominador:");
            String entrada2 = scanner.nextLine();
            int num2 = Integer.parseInt(entrada2);

            Division division = new Division(num1, num2);
            int resultado = division.dividir();
            System.out.println("Resultado de la división: " + resultado);

        } catch (Exception exception) {
            System.out.println("Excepción capturada: " + exception.getClass().getSimpleName());
            System.out.println(exception.getMessage());
        } finally {
            System.out.println("Código finalizado");
            scanner.close();
        }
    }
}
