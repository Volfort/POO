package mx.unam.die.poo.g7.practica_10.src;

/**
 * Representa una operación de división aritmética entre dos números enteros
 * 
 * @author 323036285
 * @author 323279866
 * @author 323209432
 * @author 323161891
 * @author 323063609
 * @version 1.0
 */
public class Division {

    /**
     * Numerador de la fracción 
     */
    private int numerador;

    /**
     * Denominador de la fracción
     */
    private int denominador;

    /**
     * Constructor que inicializa los operandos de la división
     * Valida que ninguno de los dos valores sea negativo
     * 
     * @param numerador Valor entero dividendo
     * @param denominador Valor entero divisor
     * @throws IllegalArgumentException Si el numerador o el denominador son menores a cero
     */
    public Division(int numerador, int denominador) throws IllegalArgumentException {
        if (numerador < 0 || denominador < 0) {
            throw new IllegalArgumentException("No se permiten números negativos");
        }
        this.numerador = numerador;
        this.denominador = denominador;
    }

    /**
     * Obtiene el valor actual del numerador
     * 
     * @return El numerador entero
     */
    public int getNumerador() {
        return this.numerador;
    }

    /**
     * Modifica el valor del numerador validando que no sea negativo
     * 
     * @param numerador Nuevo valor entero para el numerador
     * @throws IllegalArgumentException Si el numerador ingresado es menor a cero
     */
    public void setNumerador(int numerador) throws IllegalArgumentException {
        if (numerador < 0) {
            throw new IllegalArgumentException("No se permiten números negativos");
        }
        this.numerador = numerador;
    }

    /**
     * Obtiene el valor actual del denominador
     * 
     * @return El denominador entero
     */
    public int getDenominador() {
        return this.denominador;
    }

    /**
     * Modifica el valor del denominador validando que no sea negativo
     * 
     * @param denominador Nuevo valor entero para el denominador
     * @throws IllegalArgumentException Si el denominador ingresado es menor a cero
     */
    public void setDenominador(int denominador) throws IllegalArgumentException {
        if (denominador < 0) {
            throw new IllegalArgumentException("No se permiten números negativos");
        }
        this.denominador = denominador;
    }

    /**
     * Realiza el cálculo de la división  entre el numerador y el denominador
     * Si el denominador es cero, lanza la
     * excepción de tipo ArithmeticException
     * 
     * @return El cociente de la división
     * @throws ArithmeticException Si el denominador es igual a cero
     */
    public int dividir() throws ArithmeticException {
        return this.numerador / this.denominador;
    }
}
