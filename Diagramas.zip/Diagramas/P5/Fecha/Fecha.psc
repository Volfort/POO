Algoritmo Fecha
	Definir local_Dia Como Entero
	Definir local_Mes Como Cadena
	Definir local_Year Como Entero
FinAlgoritmo

Funci�n setFecha(dia,mes,year)
	local_Dia <- dia
	local_Mes <- mes
	local_Year <- year
FinFunci�n

Funci�n setDia(dia)
	local_Dia <- dia
FinFunci�n

Funci�n setMes(mes)
	local_Mes <- mes
FinFunci�n

Funci�n setYear(year)
	local_Year <- year
FinFunci�n

Funci�n showFecha
	Escribir 'La fecha es:', local_Dia, '/', local_Mes, '/', local_Year
FinFunci�n
