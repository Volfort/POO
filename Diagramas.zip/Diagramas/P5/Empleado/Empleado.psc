Algoritmo Empleado
	Definir local_nombre Como Cadena
	Definir local_apellido Como Cadena
	Definir local_SalarioM Como Real
FinAlgoritmo

Funci�n setNombre(nombre)
	local_nombre <- nombre
FinFunci�n

Funci�n setApellido(apellido)
	local_apellido <- apellido
FinFunci�n

Funci�n setSalarioM(Dinero)
	Si Dinero>0 Entonces
		local_SalarioM <- Dinero
	FinSi
FinFunci�n

Funci�n getNombre
	Escribir local_nombre
FinFunci�n

Funci�n getApellido
	Escribir local_apellido
FinFunci�n

Funci�n getSalarioM
	Escribir local_SalarioM
FinFunci�n

Funci�n getSalarioA
	Escribir local_SalarioM*12
FinFunci�n
